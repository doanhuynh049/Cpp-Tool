/*
 * Copyright (c) 1991-2006 TIBCO Software Inc.
 * All rights reserved.
 * For more information, please contact:
 * TIBCO Software Inc., Palo Alto, California, USA
 *
 * $Id: //dev/packages/tpsi/cpsi/dev/68/src/rtworks/mt.h#1 $
 */

/* =================================================================== */
/*                                                                     */
/*                      mt.h -- message types                          */
/*                                                                     */
/* =================================================================== */

#ifndef _RTWORKS_MT_H_
#define _RTWORKS_MT_H_

#endif /* _RTWORKS_MT_H_ */
